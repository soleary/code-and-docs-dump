use warnings;
use strict;
use Getopt::Std;
use File::Copy;

our ($opt_b, $opt_h);
print @ARGV;
getopts('bh');

( @ARGV == 0 || $opt_h ) && die<<'USAGE';

File Fixer v1.0
Sean O'Leary - 8/14/2001 11:21AM

A small utility for converting files from *NIX boxes
for use on the current one.  It looks for a \015\012 series,
then a lone \012 or \015, and changes them to \n's.  Exactly what
\n is is defined for the local platform, so this program must
be run on the platform it's supposed to be converting for,
otherwise, it dosen't really work, now does it?

Yes, I could make it work for all platforms all the time based on
switches, but that would be some more work, now wouldn't it.

I'll get around to it, just not right now.  I needed a thing to do
this conversion lickity-split.

Run it like this -
perl linend.pl <switches> <filenames>

Files are not modified in place, but a temporary file written and the
original clobbered.  If you want the original to stay safe, back it up
beforehand, or use the -b switch.

Switches:

    -b      Makes backup copies of affected files, with a .bak extension.
    -h      Prints this message.

USAGE

my @files = ();
foreach (@ARGV) {
    push(@files, glob($_));
}
{
    local $/ = undef;
    foreach (@files) {
        copy $_, "$_.bak" if $opt_b;
        open T, '>temp' or die "Can't open temp: $!\n";
        open F, "$_" or die "Can't open $_: $!\n";
        my $file = <F>;
        $file =~ s/(\015\012)|\012|\015/\n/g;
        print T $file;
        close T;
        close F;
        unlink $_;
        rename('temp', "$_");
    }
}
